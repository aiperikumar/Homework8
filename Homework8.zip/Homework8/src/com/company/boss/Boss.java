package com.company.boss;

import com.company.general.GameEntity;

public class Boss extends GameEntity {
    public Boss(int health, int damage) {
        super(health, damage);

    }

}
