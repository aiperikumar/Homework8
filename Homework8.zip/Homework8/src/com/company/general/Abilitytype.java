package com.company.general;

public enum Abilitytype {
    SAVE_DAMAGE_AND_REVERT,
    CRITICAL_DAMAGE,
    HEAL,
    BOOST
}
