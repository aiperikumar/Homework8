package com.company.general;

public class Main {

    public static void main(String[] args) {
        RPGGame.startGame();

    }
}
