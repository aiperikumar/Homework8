package com.company.players;

import com.company.boss.Boss;

public interface HavingAbility {
    void useAbility(Hero[] heroes, Boss boss);

}
