package com.company.players;

import com.company.boss.Boss;
import com.company.general.Abilitytype;

public class Hunter extends Hero {
    public Hunter(int health, int damage) {
        super(health, damage, Abilitytype.CRITICAL_DAMAGE);
    }

    @Override
    public void useAbility(Hero[] heroes, Boss boss) {

    }
}
