package com.company.players;

import com.company.boss.Boss;
import com.company.general.Abilitytype;

public class Magic extends Hero {
    public Magic(int health, int damage) {
        super(health, damage, Abilitytype.HEAL);
    }

    @Override
    public void useAbility(Hero[] heroes, Boss boss) {

    }
}
